package eventsystem;

import java.util.ArrayList;
import java.util.List;

public class EventManager {

    // Static Nested class for managing button press events
    public static class ButtonPressEvent implements Event {
        private String eventName;

        public ButtonPressEvent(String eventName) {
            this.eventName = eventName;
        }

        @Override
        public String getEventName() {
            return this.eventName;
        }
    }

    // Non-static nested class to manage listeners
    private List<EventListener> listeners = new ArrayList<>();

    // Method to add listeners
    public void addListener(EventListener listener) {
        listeners.add(listener);
    }

    // Method to notify all listeners of an event
    public void notifyListeners(Event event) {
        for (EventListener listener : listeners) {
            listener.handleEvent(event);
        }
    }

}
