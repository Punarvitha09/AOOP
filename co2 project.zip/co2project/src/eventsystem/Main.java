package eventsystem;

public class Main {
    public static void main(String[] args) {

        // Create an instance of EventManager
        EventManager eventManager = new EventManager();

        // Add an event listener using a lambda expression
        eventManager.addListener((event) -> {
            System.out.println("Event received: " + event.getEventName());
        });

        // Trigger a button press event
        EventManager.ButtonPressEvent buttonPressEvent = new EventManager.ButtonPressEvent("Button Pressed");

        // Notify all listeners of the button press event
        eventManager.notifyListeners(buttonPressEvent);
    }
}
