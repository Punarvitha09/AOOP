package eventsystem;

public interface Event {
    String getEventName();
}
