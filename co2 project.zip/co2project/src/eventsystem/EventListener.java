package eventsystem;

public interface EventListener {
    void handleEvent(Event event);
}
