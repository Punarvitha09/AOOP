package tests;

import java.util.Arrays;
import java.util.List;
import notifications.EmailNotificationService;
import notifications.NotificationManager;
import notifications.NotificationService;
import notifications.SMSNotificationService;
import sorting.BubbleSort;

public class BubbleSortTest {

    public static void main(String[] args) {
        testBubbleSort();
    }

    public static void testBubbleSort() {
        int[] arr = {64, 25, 12, 22, 11};
        int[] expected = {11, 12, 22, 25, 64};

        EmailNotificationService emailService = new EmailNotificationService();
        SMSNotificationService smsService = new SMSNotificationService();
        
       
        List<NotificationService> services = Arrays.asList(emailService, smsService);
        NotificationManager notificationManager = new NotificationManager(services);

        BubbleSort.bubbleSort(arr, notificationManager);

        boolean isSorted = true;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != expected[i]) {
                isSorted = false;
                break;
            }
        }

        if (isSorted) {
            System.out.println("Test Passed: Array is sorted correctly.");
        } else {
            System.out.println("Test Failed: Array is not sorted correctly.");
        }
    }
}
