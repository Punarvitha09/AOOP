package notifications;

public class SMSNotificationService implements NotificationService {
    @Override
    public void sendNotification(final String message) {
        System.out.println("Sending SMS Notification: " + message);
    }
}

