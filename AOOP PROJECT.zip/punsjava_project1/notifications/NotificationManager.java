package notifications;

import java.util.List;

public class NotificationManager {
    private final List<NotificationService> notificationServices;

    public NotificationManager(final List<NotificationService> notificationServices) {
        this.notificationServices = notificationServices;
    }

    public void notifyUser(final String message) {
        for (final NotificationService service : notificationServices) {
            service.sendNotification(message);
        }
    }
}
