package notifications;

public class PushNotificationService implements NotificationService {
    @Override
    public void sendNotification(final String message) {
        System.out.println("Sending Push Notification: " + message);
    }
}

