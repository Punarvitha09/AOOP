package notifications;

public interface NotificationService {
    void sendNotification(String message);
}
